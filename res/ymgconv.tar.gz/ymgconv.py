#! /usr/bin/env python3
##
##  ymgconv - Converts PowerPaint YMG images into standard formats
##  Copyright (C) 2016 David McMackins II
##
##  This program is free software: you can redistribute it and/or modify
##  it under the terms of the GNU Affero General Public License as published by
##  the Free Software Foundation, version 3 only.
##
##  This program is distributed in the hope that it will be useful,
##  but WITHOUT ANY WARRANTY; without even the implied warranty of
##  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##  GNU Affero General Public License for more details.
##
##  You should have received a copy of the GNU Affero General Public License
##  along with this program.  If not, see <http://www.gnu.org/licenses/>.
##

from sys import argv
from wand.color import Color
from wand.drawing import Drawing
from wand.image import Image

class YmgImage:
    def __init__(self, path):
        with open(path, 'rb') as f:
            r = f.read(2)
            if len(r) != 2:
                raise ValueError('Unexpected EOF getting image width')

            self._w = int.from_bytes(r, byteorder='little') - 2

            r = f.read(2)
            if len(r) != 2:
                raise ValueError('Unexpected EOF getting image height')

            self._h = int.from_bytes(r, byteorder='little') - 2

            r = f.read(4)
            if r != b'\x03ymg':
                raise ValueError('Invalid YMG header: {}'.format(r))

            self._data = []
            for i in range(self._h):
                r = f.read(self._w)
                self._data.append([b for b in r])
                while len(self._data[i]) < self._w:
                    self._data[i].append(0)

    def __len__(self):
        return self._h

    def __getitem__(self, i):
        return self._data[i]

    @property
    def width(self):
        return self._w

    @property
    def height(self):
        return self._h

palette = []

with open('DEFAULT.PAL', 'rb') as f:
    r = f.read(3)
    while r:
        palette.append([(color * 4.2) for color in r])
        r = f.read(3)

if len(argv) not in (2, 3):
    exit('Usage: ymg2bmp IN [OUT]')

inpath = argv[1]

if len(argv) == 3:
    outpath = argv[2]
else:
    outpath = inpath + '.bmp'

ymg = YmgImage(inpath)
with Drawing() as draw:
    for y in range(ymg.height):
        for x in range(ymg.width):
            p = palette[ymg[y][x]]
            draw.fill_color = Color('rgb({},{},{})'.format(p[0], p[1], p[2]))

            pt = (x, y)
            draw.line(pt, pt)

    with Image(width=ymg.width, height=ymg.height) as bmp:
        draw(bmp)
        bmp.save(filename=outpath)
