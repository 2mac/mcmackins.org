#! /usr/bin/env python3

from getpass import getpass

users = {
    'bob': 'chicken',
    'steve': 'spaghetti'
}

tries = 0
while tries < 3:
    tries += 1

    user = input('Username: ')
    passwd = getpass()

    try:
        if passwd == users[user]: # allow
            print('granted')
            break
        else: # deny
            print('denied')
    except KeyError:
        print('No such user')
