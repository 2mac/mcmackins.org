#! /usr/bin/env python3

from datetime import datetime

birth_year = int(input('In which year were you born? '))

current_year = datetime.now().year

diff = current_year - birth_year

new_year = current_year + diff

print('You are', diff, 'years old. In another', diff, 'years, it will be',
      str(new_year) + '.')
