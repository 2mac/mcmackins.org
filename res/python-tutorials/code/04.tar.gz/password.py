#! /usr/bin/env python3

from getpass import getpass

users = {
    'bob': 'chicken',
    'steve': 'spaghetti'
}

current_user = None
running = True

def auth():
    global current_user
    user = input('Username: ')
    passwd = getpass()

    try:
        if passwd == users[user]:
            print('Welcome.')
            current_user = user
        else:
            print('Invalid password for user.')
    except KeyError:
        print('No such user.')

    print()

def add_user(user, passwd):
    try:
        if users[user]:
            raise ValueError()
    except KeyError:
        users[user] = passwd

def del_user(user):
    del users[user]

while running:
    while not current_user:
        auth()

    cmd = input(current_user + '> ')

    if 'add' == cmd:
        new_u = input('New username: ')
        new_p = getpass('New password: ')

        if new_p != getpass('Confirm: '):
            print('Passwords do not match.')
        else:
            try:
                add_user(new_u, new_p)
            except ValueError:
                print('User already exists.')
    elif 'del' == cmd:
        try:
            del_user(input('Which user? '))
        except KeyError:
            print('No such user.')
    elif 'passwd' == cmd:
        cur = getpass('Current password: ')
        if cur != users[current_user]:
            print('Wrong password.')
        else:
            new = getpass('New password: ')
            if new != getpass('Confirm: '):
                print('Passwords do not match.')
            else:
                users[current_user] = new
    elif 'list' == cmd:
        for user in users.keys():
            print(user)
    elif 'logout' == cmd:
        current_user = None
    elif 'shutdown' == cmd:
        running = False
    else:
        print('No such command: ' + cmd)

    print()
